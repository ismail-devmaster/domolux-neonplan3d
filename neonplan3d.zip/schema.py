"""Validation schemas for the building data (mirrors frontend/src/model.ts).

Known fields are checked; fields added by newer frontends are passed through (extra=ALLOW_EXTRA),
so saving keeps working after a frontend update until Home Assistant restarts with the new backend.
"""

from __future__ import annotations

import math
from typing import Any

import voluptuous as vol

MAX_FLOORS = 20
MAX_ROOMS = 200
MAX_POINTS = 200
# entities a room keeps out of its panel or shows without state: an LED strip from Govee2MQTT alone brings
# hundreds of segment lights into an area (#645)
MAX_HIDDEN = 2000
MAX_ITEMS = 1000
MAX_IMAGE_CHARS = 8 * 1024 * 1024

_ID = vol.All(str, vol.Length(min=1, max=64), vol.Match(r"^[A-Za-z0-9_\-.]+$"))
_NAME = vol.All(str, vol.Length(max=100))
_COORD = vol.All(vol.Coerce(float), vol.Range(min=-1000, max=1000))
_LENGTH = vol.All(vol.Coerce(float), vol.Range(min=0, max=100))
_POINT = vol.All([_COORD], vol.Length(min=2, max=2))
_ENTITY_REF = vol.Any(None, vol.All(str, vol.Length(max=255)))

_SENSOR_REF = vol.Any(None, vol.All(str, vol.Length(max=255)))

# what a module keeps on an item of the plan, by the module's id (plain JSON the module reads itself)
_MODULE_DATA = vol.Any(None, vol.All({vol.All(str, vol.Length(min=1, max=64)): dict}, vol.Length(max=20)))

# a camera to open with: angles, distance and (optional) the point it looks at; for a floor or a room the
# point's height is counted from that floor
START_VIEW_SCHEMA = vol.Schema(
    {
        # the camera may have turned round several times: the angle counts once round (#416)
        vol.Required("theta"): vol.All(vol.Coerce(float), lambda v: math.remainder(v, math.tau)),
        vol.Required("phi"): vol.All(vol.Coerce(float), vol.Range(min=0, max=3.2)),
        vol.Required("radius"): vol.All(vol.Coerce(float), vol.Range(min=1, max=500)),
        vol.Optional("target"): {
            vol.Required("x"): vol.All(vol.Coerce(float), vol.Range(min=-1000, max=1000)),
            vol.Required("y"): vol.All(vol.Coerce(float), vol.Range(min=-200, max=200)),
            vol.Required("z"): vol.All(vol.Coerce(float), vol.Range(min=-1000, max=1000)),
        },
    },
    extra=vol.ALLOW_EXTRA,
)

ROOM_SCHEMA = vol.Schema(
    {
        # room climate read from chosen sensors (None = automatic, "none" = no value)
        vol.Optional("climate", default=None): vol.Any(
            None,
            {
                vol.Optional("temperature", default=None): _SENSOR_REF,
                vol.Optional("humidity", default=None): _SENSOR_REF,
                vol.Optional("co2", default=None): _SENSOR_REF,
            },
        ),
        vol.Required("id"): _ID,
        vol.Required("name"): _NAME,
        # further names the voice answers to
        vol.Optional("aliases"): vol.All([vol.All(str, vol.Length(min=1, max=60))], vol.Length(max=12)),
        vol.Required("area_id"): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # the script or button that sends the robot vacuum to clean this room
        vol.Optional("cleaning"): vol.Any(None, vol.All(str, vol.Length(max=255))),
        vol.Required("points"): vol.All([_POINT], vol.Length(min=3, max=MAX_POINTS)),
        vol.Required("floor_material"): vol.All(str, vol.Length(max=32)),
        # the room's name moved from its middle in the plan and in 3D (metres; None = in the middle)
        vol.Optional("label_offset"): vol.Any(
            None, vol.All([vol.All(vol.Coerce(float), vol.Range(min=-100, max=100))], vol.Length(min=2, max=2))
        ),
        # the camera this room opens with when it is tapped (None = framed from above)
        vol.Optional("start_view", default=None): vol.Any(None, START_VIEW_SCHEMA),
        # entities shown in the room's panel although they are not in the plan
        vol.Optional("panel", default=list): vol.All([vol.All(str, vol.Length(max=255))], vol.Length(max=100)),
        # entities of the area kept out of the room panel
        vol.Optional("hidden", default=list): vol.All([vol.All(str, vol.Length(max=255))], vol.Length(max=MAX_HIDDEN)),
        # entities whose state text the room panel leaves out
        vol.Optional("no_state", default=list): vol.All(
            [vol.All(str, vol.Length(max=255))], vol.Length(max=MAX_HIDDEN)
        ),
        # split points on each edge (metres from the edge's start) that cut the wall into parts of their own
        vol.Optional("wall_splits"): vol.All(
            [vol.Any(None, vol.All([vol.All(vol.Coerce(float), vol.Range(min=0.05, max=200))], vol.Length(max=16)))],
            vol.Length(max=MAX_POINTS),
        ),
        # ceiling height of the room (None = the floor height)
        vol.Optional("ceiling_height"): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=1, max=30))),
        # colour of the room's side of each wall ("#rrggbb", None = wall_color), and of all its walls (homely styles)
        vol.Optional("wall_colors"): vol.Any(
            None, vol.All([vol.Any(None, vol.All(str, vol.Length(max=16)))], vol.Length(max=MAX_POINTS))
        ),
        vol.Optional("wall_color"): vol.Any(None, vol.All(str, vol.Length(max=16))),
        # thickness of the wall on each edge in m (None = the building's exterior / interior thickness)
        vol.Optional("wall_thickness"): vol.All(
            [vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0.02, max=1.5)))],
            vol.Length(max=MAX_POINTS),
        ),
        # height of the wall on each edge (None = full floor height, 0 = no wall), aligned with the points;
        # a split edge may carry one height per part instead
        vol.Optional("wall_heights"): vol.All(
            [
                vol.Any(
                    None,
                    vol.All(vol.Coerce(float), vol.Range(min=0, max=20)),
                    vol.All([vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=20)))], vol.Length(max=32)),
                )
            ],
            vol.Length(max=MAX_POINTS),
        ),
        # sloping walls: the height at an edge's start and end corner (None = its plain height)
        vol.Optional("wall_slopes"): vol.All(
            [
                vol.Any(
                    None,
                    vol.All([vol.All(vol.Coerce(float), vol.Range(min=0.05, max=20))], vol.Length(min=2, max=2)),
                )
            ],
            vol.Length(max=MAX_POINTS),
        ),
        # what a module keeps for this room or the whole house (its settings), by the module's id
        vol.Optional("mods"): _MODULE_DATA,
    },
    extra=vol.ALLOW_EXTRA,
)

# door looks (room door, front doors with glass and sidelights, glass and sliding door) and window looks
_OPENING_STYLES = ["interior", "front", "front_glass", "sidelight", "sidelights", "glass", "sliding", "passage"]
_OPENING_STYLES += ["standard", "bars", "glass_wall", "slide"]

OPENING_SCHEMA = vol.Schema(
    {
        vol.Required("id"): _ID,
        vol.Required("room_id"): _ID,
        vol.Required("edge"): vol.All(int, vol.Range(min=0, max=MAX_POINTS)),
        vol.Required("offset"): _LENGTH,
        # an opening in a free wall: the wall's id (room_id is then the room the wall stands in)
        vol.Optional("wall", default=None): vol.Any(None, _ID),
        vol.Required("width"): _LENGTH,
        vol.Required("type"): vol.In(["door", "window", "garage"]),
        vol.Required("sill"): _LENGTH,
        vol.Required("height"): _LENGTH,
        # window sash hinge as seen from the room; entities: None = assign automatically by area,
        # "none" = no entity
        vol.Optional("hinge", default="left"): vol.In(["left", "right"]),
        # double doors and windows: two leaves, the second with a contact of its own
        vol.Optional("leaves", default=1): vol.In([1, 2]),
        # doors: swing into the room ("in") or to the other side ("out")
        vol.Optional("swing", default="in"): vol.In(["in", "out"]),
        # windows: hung at the top, the bottom opens outwards
        vol.Optional("top_hung", default=False): bool,
        # look: None = automatic (front door in an exterior wall, room door inside; plain window)
        vol.Optional("style", default=None): vol.Any(None, vol.In(_OPENING_STYLES)),
        # a garage door: sectional (None) or up-and-over
        vol.Optional("garage_kind"): vol.Any(None, vol.In(["sectional", "tilt"])),
        # front doors with sidelights: one on the hinge side, and the widths (None = automatic)
        vol.Optional("sidelight_hinge", default=False): bool,
        vol.Optional("sidelight_width", default=None): vol.Any(
            None, vol.All(vol.Coerce(float), vol.Range(min=0.1, max=3))
        ),
        vol.Optional("sidelight_width2", default=None): vol.Any(
            None, vol.All(vol.Coerce(float), vol.Range(min=0.1, max=3))
        ),
        vol.Optional("contact2", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # windows: a plain contact, a handle sensor (open / tilted / closed), or a contact and a tilt sensor
        vol.Optional("sensor", default=None): vol.Any(None, vol.In(["contact", "handle", "contact_tilt"])),
        # the same for the second leaf of a double window
        vol.Optional("sensor2", default=None): vol.Any(None, vol.In(["contact", "handle", "contact_tilt"])),
        vol.Optional("tilt2", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # a sensor with the blind's position while it moves (covers that only report at the end)
        vol.Optional("position", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # the position sensor counts the other way round (0 = open)
        vol.Optional("position_inverted", default=False): bool,
        # a venetian blind whose cover reports its slats the other way round (0 = open): turned in 3D and the sliders
        vol.Optional("slat_invert"): vol.Any(None, bool),
        # where the blind sits: outside as a roller shutter (None) or inside the room as a roller shade
        vol.Optional("blind_side"): vol.Any(None, vol.In(["inside", "outside"])),
        # windows: a sensor with the sash's tilt angle (degrees), the angle that counts as fully tilted,
        # an offset the sensor reports when closed, and the other sign
        vol.Optional("tilt_angle", default=None): _ENTITY_REF,
        vol.Optional("tilt_max", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=1, max=90))),
        vol.Optional("tilt_offset", default=None): vol.Any(
            None, vol.All(vol.Coerce(float), vol.Range(min=-360, max=360))
        ),
        vol.Optional("tilt_invert", default=False): bool,
        # a door without a sensor is drawn closed instead of half open
        vol.Optional("shut", default=False): bool,
        vol.Optional("open_angle", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=180))),
        # the contact sensors report the other way round (on = closed)
        vol.Optional("contact_invert", default=False): bool,
        # no rain warning for this window
        vol.Optional("rain_ignore", default=False): bool,
        # a window below the ground: its light well (False: none) and how far its rim stands above the ground
        vol.Optional("well", default=True): bool,
        vol.Optional("well_rim", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=-0.3, max=1))),
        # how far the light well reaches out from the wall (None: 0.8 m)
        vol.Optional("well_depth", default=None): vol.Any(
            None, vol.All(vol.Coerce(float), vol.Range(min=0.2, max=1.5))
        ),
        # highlight in 3D while open (None) or while closed ("closed": a WC or a child's room door)
        vol.Optional("mark", default=None): vol.Any(None, vol.In(["closed"])),
        # windows: board inside and sill outside, "auto" (from 0.3 m sill height, none for a window
        # directly above another opening), "none", "inside" or "outside"
        vol.Optional("sill_board", default="auto"): vol.Any(None, vol.In(["auto", "none", "inside", "outside"])),
        # ask before moving the blind or garage door (no moving by a swipe then)
        vol.Optional("confirm", default=False): bool,
        vol.Optional("cover", default=None): _ENTITY_REF,
        vol.Optional("contact", default=None): _ENTITY_REF,
        vol.Optional("tilt", default=None): _ENTITY_REF,
    },
    extra=vol.ALLOW_EXTRA,
)

# screens: a picture shown while an entity is in a state (an image id of the image store, or an http URL)
_SCREEN_PICTURE_SCHEMA = vol.Schema(
    {
        vol.Required("entity"): vol.All(str, vol.Length(max=255)),
        # compare this attribute (e.g. app_name) instead of the state
        vol.Optional("attribute", default=None): vol.Any(None, vol.All(str, vol.Length(max=64))),
        vol.Required("state"): vol.All(str, vol.Length(max=128)),
        vol.Required("image"): vol.All(str, vol.Length(max=2048)),
    }
)

# Auto Pro: the car's entities on a parking spot (None = found on the car's device)
_CAR_ENTITY = vol.Any(None, vol.All(str, vol.Length(max=255)))
CAR_SCHEMA = vol.Schema(
    {
        vol.Optional("device", default=None): _CAR_ENTITY,
        vol.Optional("soc", default=None): _CAR_ENTITY,
        vol.Optional("range", default=None): _CAR_ENTITY,
        vol.Optional("charging", default=None): _CAR_ENTITY,
        vol.Optional("plugged", default=None): _CAR_ENTITY,
        vol.Optional("lock", default=None): _CAR_ENTITY,
        vol.Optional("climate", default=None): _CAR_ENTITY,
        vol.Optional("tracker", default=None): _CAR_ENTITY,
    },
    extra=vol.ALLOW_EXTRA,
)
# parking spots: which vehicle a state of the type sensor means
_VEHICLE_TYPE_SCHEMA = vol.Schema(
    {vol.Required("state"): vol.All(str, vol.Length(max=64)), vol.Required("vehicle"): vol.All(str, vol.Length(max=96))}
)

# the kinds of waste a bin can take (household.ts WASTE_KINDS)
WASTE_KINDS = ["rest", "bio", "paper", "plastic", "glass", "garden", "recycling", "other"]
# digital picture frames: what a frame's face shows
FRAME_KINDS = ["calendar", "camera", "media", "person", "photo", "weather", "todo", "board", "persons"]

FURNITURE_SCHEMA = vol.Schema(
    {
        vol.Required("id"): _ID,
        # built-in type, or "pack:<pack id>:<item id>" for furniture from a pack
        vol.Required("type"): vol.All(str, vol.Length(max=96)),
        vol.Required("x"): _COORD,
        vol.Required("z"): _COORD,
        vol.Required("rotation"): vol.Coerce(float),
        vol.Required("w"): _LENGTH,
        vol.Required("d"): _LENGTH,
        vol.Required("h"): _LENGTH,
        vol.Required("variant"): vol.Any(None, vol.All(str, vol.Length(max=32))),
        # its own name (e.g. "Wechselrichter Nord"); None = the type's name; show_name puts it under the marker
        vol.Optional("name", default=None): vol.Any(None, vol.All(str, vol.Length(max=60))),
        vol.Optional("aliases"): vol.All([vol.All(str, vol.Length(min=1, max=60))], vol.Length(max=12)),
        vol.Optional("show_name", default=False): bool,
        # lamps / lights: how strongly they glow in 3D (None = as reported)
        vol.Optional("glow_scale", default=None): vol.Any(
            None, vol.All(vol.Coerce(float), vol.Range(min=0.1, max=1.5))
        ),
        # lamps: always drawn in this colour ("#rrggbb"), whatever the light reports (None = the light's colour)
        vol.Optional("glow_color", default=None): vol.Any(None, vol.Match(r"^#[0-9a-fA-F]{6}$")),
        # linked entities (e.g. the TV's media player, a power sensor): None = automatic, "none" = no entity
        vol.Optional("entity", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        vol.Optional("power", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # smart fridge: door sensors of the left and the right door
        vol.Optional("door_left", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        vol.Optional("door_right", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # home battery: state of charge; wallbox: status (charging, plugged in)
        vol.Optional("soc", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # home battery: a separate charging power sensor when the power sensor only reports discharging
        vol.Optional("charge", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # meter: a separate export power sensor when the power sensor only reports import
        vol.Optional("export", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # Energie Pro: a hologram card over the device (power now, today's kWh, day curve)
        vol.Optional("holo", default=False): bool,
        # Energie Pro, inverter: False hides the plant's card over its field
        vol.Optional("plant_card"): bool,
        # Energie Pro, inverter: its plant card moved along the eave / up the slope (m)
        vol.Optional("plant_right"): vol.All(vol.Coerce(float), vol.Range(min=-30, max=30)),
        vol.Optional("plant_up"): vol.All(vol.Coerce(float), vol.Range(min=-30, max=30)),
        # Energie Pro, inverter: its cable ends at the grid point instead of the meter (#841)
        vol.Optional("cable_to"): vol.Any(None, vol.In(["meter", "grid"])),
        vol.Optional("status", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # robot vacuum: sensor naming the room it cleans right now (None = automatic)
        vol.Optional("room_sensor", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # ask before switching the linked entity
        vol.Optional("confirm", default=False): bool,
        # its marker in 3D: None = automatic, always, without watts, or hidden
        vol.Optional("marker", default=None): vol.Any(None, vol.In(["always", "active", "no_power", "never"])),
        # an own symbol for the marker: a Material Design icon name without "mdi:"
        vol.Optional("icon", default=None): vol.Any(None, vol.All(str, vol.Length(max=64))),
        # parking spots: the vehicle shown (a pack item type) while the entity reports a car, its size
        # factor, and a sensor naming the kind of vehicle with a state -> vehicle mapping
        # height of the bottom edge above the floor (None = default: the floor, a pack item's mount)
        # below 0 only outside the rooms (outdoor steps down to a sunken terrace, #897); the editor keeps rooms at 0
        vol.Optional("mount_y", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=-5, max=10))),
        # any furniture: an entity whose state the item shows (glows while on / occupied / home), optionally
        # two of them for the halves of a bed (left/right) or a bunk bed (bottom/top)
        vol.Optional("state_entity", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        vol.Optional("state_entity2", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        vol.Optional("state_split", default=None): vol.Any(None, vol.In(["left_right", "top_bottom"])),
        # lamps: a second entity with the colour and brightness (a relay switches, the bulb knows its colour)
        vol.Optional("color_entity", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # any electric item: a sensor whose value stands at its symbol (a boiler's water temperature)
        vol.Optional("extra", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # ceiling fan with light: its fan entity (the blades turn with its speed)
        vol.Optional("fan"): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # mirrored left-right
        vol.Optional("mirror", default=False): bool,
        # awning: the fabric's fall (degrees), the valance, a position sensor, its run time and the other direction
        vol.Optional("awning_pitch", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=80))),
        vol.Optional("awning_valance", default=True): bool,
        vol.Optional("awning_position", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        vol.Optional("awning_time", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=2, max=300))),
        vol.Optional("awning_invert", default=False): bool,
        # household: a waste bin's kind and colours, its calendar (Haushalt Pro); a mailbox's emptying door
        vol.Optional("bin_kind"): vol.Any(None, vol.In(WASTE_KINDS)),
        vol.Optional("bin_color"): vol.Any(None, vol.Match(r"^#[0-9a-fA-F]{6}$")),
        # live parts of a pack item: the entity of each of its slots
        vol.Optional("binds"): vol.Any(
            None,
            vol.All({vol.All(str, vol.Length(min=1, max=40)): vol.All(str, vol.Length(max=255))}, vol.Length(max=16)),
        ),
        # own colours in the homely styles: wood, fabric, fronts and the carcass ("body", 3.5; each "#rrggbb",
        # missing = the look's own)
        vol.Optional("finish"): vol.Any(
            None,
            vol.Schema(
                {
                    vol.Optional(k): vol.Any(None, vol.Match(r"^#[0-9a-fA-F]{6}$"))
                    for k in ("wood", "fabric", "front", "body")
                }
            ),
        ),
        # a neon sign: its own text and the colour of its tubes
        vol.Optional("sign_text"): vol.Any(None, vol.All(str, vol.Length(max=80))),
        vol.Optional("sign_color"): vol.Any(None, vol.Match(r"^#[0-9a-fA-F]{6}$")),
        vol.Optional("bin_lid"): vol.Any(None, vol.Match(r"^#[0-9a-fA-F]{6}$")),
        vol.Optional("bin_source"): vol.Any(None, vol.All(str, vol.Length(max=255))),
        vol.Optional("bin_match"): vol.Any(None, vol.All(str, vol.Length(max=120))),
        vol.Optional("mailbox_door"): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # digital picture frames: what the face shows and where it comes from (entities, or a URL for a photo)
        vol.Optional("frame_kind"): vol.Any(None, vol.In(FRAME_KINDS)),
        vol.Optional("frame_source"): vol.Any(None, vol.All(str, vol.Length(max=4000))),
        vol.Optional("frame_trigger"): vol.Any(None, vol.All(str, vol.Length(max=255))),
        vol.Optional("frame_remind"): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=1440))),
        vol.Optional("frame_interval"): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=3, max=3600))),
        # Haushalt Pro: on while the bin is out (an input_boolean a nightly automation resets)
        vol.Optional("bin_out"): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # Haushalt Pro: a plant's moisture, an appliance's time left, a service, a fridge's door alarm
        vol.Optional("moisture"): vol.Any(None, vol.All(str, vol.Length(max=255))),
        vol.Optional("moisture_min"): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=100))),
        vol.Optional("remaining"): vol.Any(None, vol.All(str, vol.Length(max=255))),
        vol.Optional("service"): vol.Any(None, vol.All(str, vol.Length(max=255))),
        vol.Optional("service_min"): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=1000))),
        # a second service (a robot vacuum's dock) with its own threshold
        vol.Optional("service2"): vol.Any(None, vol.All(str, vol.Length(max=255))),
        vol.Optional("service2_min"): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=1000))),
        vol.Optional("door_alarm"): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0.5, max=120))),
        # LED strip: tilt about its length (degrees) and standing upright
        vol.Optional("tilt", default=0.0): vol.All(vol.Coerce(float), vol.Range(min=-90, max=90)),
        vol.Optional("upright", default=False): bool,
        # access point: its clients sensor; water heater: its water temperature
        vol.Optional("clients"): vol.Any(None, vol.All(str, vol.Length(max=255))),
        vol.Optional("water_temp"): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # wall switch and socket: one entry per gang (its entity, a socket's power sensor)
        vol.Optional("gangs"): vol.Any(
            None,
            vol.All(
                [
                    vol.Schema(
                        {
                            vol.Optional("entity", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
                            vol.Optional("power", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
                        }
                    )
                ],
                vol.Length(max=4),
            ),
        ),
        # LED strip: rising along its length (degrees), e.g. up the stairs
        vol.Optional("rise"): vol.All(vol.Coerce(float), vol.Range(min=-80, max=80)),
        vol.Optional("pictures", default=[]): vol.All([_SCREEN_PICTURE_SCHEMA], vol.Length(max=20)),
        # screens: the screen around a rule picture is dark (default) or white
        vol.Optional("screen_bg", default="black"): vol.In(["black", "white"]),
        vol.Optional("vehicle", default=None): vol.Any(None, vol.All(str, vol.Length(max=96))),
        # Pool Pro: the sand filter's six-way valve and whether a ball valve is open
        vol.Optional("valve_position", default=None): vol.Any(
            None, vol.In(["filter", "backwash", "rinse", "waste", "recirculate", "closed"])
        ),
        vol.Optional("valve_open", default=None): vol.Any(None, bool),
        # Auto Pro: the car's entities
        vol.Optional("car", default=None): vol.Any(None, CAR_SCHEMA),
        vol.Optional("scale", default=1.0): vol.All(vol.Coerce(float), vol.Range(min=0.2, max=2)),
        vol.Optional("type_entity", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        vol.Optional("types", default=[]): vol.All([_VEHICLE_TYPE_SCHEMA], vol.Length(max=20)),
        # furniture block: items with the same group id move and turn together (a kitchen, a wall unit)
        vol.Optional("group", default=None): vol.Any(None, vol.All(str, vol.Length(max=64))),
        # fixed against moving by accident
        vol.Optional("locked", default=None): vol.Any(None, bool),
        # shown in 3D only while an entity is in a state (decoration for a season)
        vol.Optional("show_if", default=None): vol.Any(
            None,
            vol.Schema(
                {
                    vol.Required("entity"): vol.All(str, vol.Length(max=255)),
                    vol.Optional("state", default=None): vol.Any(None, vol.All(str, vol.Length(max=120))),
                }
            ),
        ),
        # a module's own data for this item
        vol.Optional("mods"): _MODULE_DATA,
    },
    extra=vol.ALLOW_EXTRA,
)

PLACEMENT_SCHEMA = vol.Schema(
    {
        vol.Required("entity_id"): vol.All(str, vol.Length(max=255)),
        vol.Required("x"): _COORD,
        vol.Required("z"): _COORD,
        vol.Required("y"): vol.Any(None, _LENGTH),
        # lights: how the lamp is mounted (None = ceiling)
        vol.Optional("mount", default=None): vol.Any(None, vol.In(["ceiling", "floor", "table", "wall"])),
        # a light kept as a device pin on purpose (not turned into a lamp on load)
        vol.Optional("pin"): bool,
        # turn around the vertical axis (degrees)
        vol.Optional("rotation", default=0.0): vol.Coerce(float),
        # cameras: opening angle (degrees) and reach (m) of the field of view; None = default
        vol.Optional("fov", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=10, max=360))),
        vol.Optional("reach", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0.5, max=50))),
        vol.Optional("tilt", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=90))),
        # ask before switching this device from the 3D view, the quick menu or the room panel
        vol.Optional("confirm", default=False): bool,
        # its marker in 3D: None = automatic, always, without watts, or hidden
        vol.Optional("marker", default=None): vol.Any(None, vol.In(["always", "active", "no_power", "never"])),
        # an own symbol for the marker: a Material Design icon name without "mdi:"
        vol.Optional("icon", default=None): vol.Any(None, vol.All(str, vol.Length(max=64))),
        # an own name in the plan, without renaming the entity; show_name puts it under the marker
        vol.Optional("name", default=None): vol.Any(None, vol.All(str, vol.Length(max=60))),
        vol.Optional("aliases"): vol.All([vol.All(str, vol.Length(min=1, max=60))], vol.Length(max=12)),
        vol.Optional("show_name", default=False): bool,
        # lamps / lights: how strongly they glow in 3D (None = as reported)
        vol.Optional("glow_scale", default=None): vol.Any(
            None, vol.All(vol.Coerce(float), vol.Range(min=0.1, max=1.5))
        ),
        # Energie Pro: a glass card over the placed device (a smart plug)
        vol.Optional("holo", default=False): bool,
        # cameras: show the field-of-view wedge on the floor (None = yes)
        vol.Optional("cone", default=None): vol.Any(None, bool),
        # detection pins over the camera (None = shown); off leaves only the wedge turning red
        vol.Optional("detect_pins", default=None): vol.Any(None, bool),
        vol.Optional("detect_popup", default=False): bool,
        # fixed against moving by accident
        vol.Optional("locked", default=None): vol.Any(None, bool),
    },
    extra=vol.ALLOW_EXTRA,
)

BACKGROUND_SCHEMA = vol.Schema(
    {
        vol.Required("image_id"): _ID,
        vol.Required("x"): _COORD,
        vol.Required("z"): _COORD,
        vol.Required("width"): vol.All(vol.Coerce(float), vol.Range(min=0.1, max=1000)),
        vol.Required("opacity"): vol.All(vol.Coerce(float), vol.Range(min=0, max=1)),
        # turn about the picture's middle (degrees)
        vol.Optional("rotation", default=0.0): vol.All(vol.Coerce(float), vol.Range(min=-360, max=360)),
    },
    extra=vol.ALLOW_EXTRA,
)

# Pool Pro: water temperature, heat pump, filter pump, light, pH, chlorine and cover of a pool
_POOL_ENTITY = vol.Any(None, vol.All(str, vol.Length(max=255)))
_POINT = vol.All([vol.Coerce(float)], vol.Length(min=2, max=2))
POOL_PORT_SCHEMA = vol.Schema(
    {
        vol.Required("id"): vol.All(str, vol.Length(max=80)),
        vol.Required("kind"): vol.In(["skimmer", "drain", "inlet", "waste"]),
        vol.Required("x"): vol.Coerce(float),
        vol.Required("z"): vol.Coerce(float),
        # skimmer and inlet: how far below the water line (m)
        vol.Optional("depth", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=5))),
    },
    extra=vol.ALLOW_EXTRA,
)
POOL_FITTING_SCHEMA = vol.Schema(
    {
        vol.Required("id"): vol.All(str, vol.Length(max=80)),
        vol.Required("kind"): vol.In(["valve", "sight"]),
        vol.Required("at"): vol.All(vol.Coerce(float), vol.Range(min=0, max=1000)),
        vol.Optional("open", default=True): bool,
    },
    extra=vol.ALLOW_EXTRA,
)
POOL_PIPE_SCHEMA = vol.Schema(
    {
        vol.Required("id"): vol.All(str, vol.Length(max=80)),
        vol.Required("from"): vol.All(str, vol.Length(max=120)),
        vol.Required("to"): vol.All(str, vol.Length(max=120)),
        vol.Required("floor_id"): vol.All(str, vol.Length(max=80)),
        vol.Optional("points", default=list): vol.All([_POINT], vol.Length(max=80)),
        vol.Optional("height", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=-5, max=10))),
        # a height per point (laid on a wall: up from the floor, along, round the corner, down into the ground)
        vol.Optional("heights", default=None): vol.Any(
            None,
            vol.All([vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=-5, max=10)))], vol.Length(max=80)),
        ),
        # ball valves and sight glasses in the pipe, at a distance along it
        vol.Optional("fittings", default=None): vol.Any(None, vol.All([POOL_FITTING_SCHEMA], vol.Length(max=40))),
    },
    extra=vol.ALLOW_EXTRA,
)
# a T-piece where pipes meet (a node of the pipes like a port or a device)
POOL_JOINT_SCHEMA = vol.Schema(
    {
        vol.Required("id"): vol.All(str, vol.Length(max=80)),
        vol.Required("x"): vol.Coerce(float),
        vol.Required("z"): vol.Coerce(float),
        vol.Required("y"): vol.All(vol.Coerce(float), vol.Range(min=-5, max=10)),
        # a T- or Y-piece, or a hole through a wall (its normal into the room, the wall's depth) or the floor
        vol.Optional("kind", default=None): vol.Any(None, vol.In(["tee", "y", "wall", "floor"])),
        vol.Optional("name", default=None): vol.Any(None, vol.All(str, vol.Length(max=60))),
        vol.Optional("nx", default=None): vol.Any(None, vol.Coerce(float)),
        vol.Optional("nz", default=None): vol.Any(None, vol.Coerce(float)),
        vol.Optional("depth", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=2))),
    },
    extra=vol.ALLOW_EXTRA,
)
POOL_SCHEMA = vol.Schema(
    {
        **{
            vol.Optional(role): _POOL_ENTITY
            for role in ("temperature", "heater", "pump", "light", "ph", "chlorine", "salt", "cover")
        },
        vol.Optional("ports"): vol.All([POOL_PORT_SCHEMA], vol.Length(max=40)),
        vol.Optional("pipes"): vol.All([POOL_PIPE_SCHEMA], vol.Length(max=80)),
        vol.Optional("joints"): vol.All([POOL_JOINT_SCHEMA], vol.Length(max=80)),
    },
    extra=vol.ALLOW_EXTRA,
)

OUTDOOR_TYPES = ["lawn", "terrace", "path", "driveway", "pool", "bed", "wild", "hedge", "fence", "pergola", "balcony"]

# a gate in a fence (#818): a gap in one edge with a leaf that opens with its entity
GATE_SCHEMA = vol.Schema(
    {
        vol.Required("id"): _ID,
        vol.Required("edge"): vol.All(vol.Coerce(int), vol.Range(min=0, max=MAX_POINTS)),
        vol.Required("at"): vol.All(vol.Coerce(float), vol.Range(min=0, max=1000)),
        vol.Required("width"): vol.All(vol.Coerce(float), vol.Range(min=0.3, max=20)),
        vol.Optional("kind", default="swing"): vol.In(["swing", "double", "slide"]),
        vol.Optional("flip", default=False): bool,
        vol.Optional("outward", default=False): bool,
        vol.Optional("entity", default=None): _ENTITY_REF,
        vol.Optional("contact", default=None): _ENTITY_REF,
        vol.Optional("time", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=1, max=300))),
    },
    extra=vol.ALLOW_EXTRA,
)

OUTDOOR_SCHEMA = vol.Schema(
    {
        vol.Required("id"): _ID,
        vol.Required("type"): vol.In(OUTDOOR_TYPES),
        vol.Required("points"): vol.All([_POINT], vol.Length(min=3, max=MAX_POINTS)),
        # hedges and fences: their height (None = default); outline False hides the neon line
        vol.Optional("height", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0.1, max=6))),
        vol.Optional("outline", default=True): bool,
        # height offset in m (a driveway down to a lower garage, a raised terrace)
        # (None = 0: the editor clears the field when it is set back to 0, #242)
        vol.Optional("offset", default=0.0): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=-10, max=10))),
        # fall in m across the area along slope_dir (the high edge sits at the offset)
        vol.Optional("slope", default=0.0): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=20))),
        vol.Optional("slope_dir", default="x"): vol.In(["x", "-x", "z", "-z"]),
        # fences and pergolas: the closing edge is left out; pergola: X-bracing on the sides
        vol.Optional("open", default=False): bool,
        vol.Optional("bracing", default=False): bool,
        # fences: gates cut into the edges
        vol.Optional("gates"): vol.All([GATE_SCHEMA], vol.Length(max=20)),
        # cut out of every area beneath it that contains it
        vol.Optional("cut", default=False): bool,
        # pools: round or oval, resized as a whole
        vol.Optional("pool_shape", default=None): vol.Any(None, vol.In(["round", "oval"])),
        # pools: standing on the ground instead of let into it
        vol.Optional("above", default=False): bool,
        # pool: depth of the basin (rim to floor) and, in the ground, the rim's height above the lawn
        vol.Optional("depth", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=5))),
        vol.Optional("rim", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=-0.5, max=2))),
        # Pool Pro: the pool's entities
        vol.Optional("pool", default=None): vol.Any(None, POOL_SCHEMA),
        # an outdoor area like a room (#100): its name and Home Assistant area
        vol.Optional("name", default=None): vol.Any(None, vol.All(str, vol.Length(max=80))),
        vol.Optional("area_id", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # like a room's: entities pinned to its panel, kept out of it, or shown without their state (#597)
        vol.Optional("panel"): vol.All([vol.All(str, vol.Length(max=255))], vol.Length(max=100)),
        vol.Optional("hidden"): vol.All([vol.All(str, vol.Length(max=255))], vol.Length(max=MAX_HIDDEN)),
        vol.Optional("no_state"): vol.All([vol.All(str, vol.Length(max=255))], vol.Length(max=MAX_HIDDEN)),
        # a module's own data for this area
        vol.Optional("mods"): _MODULE_DATA,
    },
    extra=vol.ALLOW_EXTRA,
)

_COORD = vol.All(vol.Coerce(float), vol.Range(min=-1000, max=1000))
_HEIGHT = vol.All(vol.Coerce(float), vol.Range(min=-50, max=200))

# one roof section of a "custom" roof: a rectangle with its own shape, ridge direction, eaves and pitches
ROOF_SECTION_SCHEMA = vol.Schema(
    {
        vol.Required("id"): _ID,
        vol.Required("x0"): _COORD,
        vol.Required("z0"): _COORD,
        vol.Required("x1"): _COORD,
        vol.Required("z1"): _COORD,
        vol.Optional("shape", default="gable"): vol.In(
            ["gable", "hip", "halfhip", "pyramid", "mansard", "pent", "flat", "parapet"]
        ),
        vol.Optional("axis", default="x"): vol.In(["x", "z"]),
        vol.Required("eave_a"): _HEIGHT,
        vol.Required("eave_b"): _HEIGHT,
        vol.Optional("pitch_a", default=35): vol.All(vol.Coerce(float), vol.Range(min=0, max=80)),
        vol.Optional("pitch_b", default=35): vol.All(vol.Coerce(float), vol.Range(min=0, max=80)),
        # mansard: the slope of the upper part (None or missing = 30 degrees, the frontend keeps it in 5 ... 60, #1183)
        vol.Optional("pitch_upper"): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=80))),
        vol.Required("base"): _HEIGHT,
        vol.Optional("overhang", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=2))),
        # the overhang per side set by hand (a, b, u0, u1; None = automatic, #863)
        vol.Optional("overhang_sides"): vol.Any(
            None,
            vol.All(
                [vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=2)))],
                vol.Length(min=4, max=4),
            ),
        ),
        vol.Optional("flip", default=False): bool,
        # a flat roof as a free shape: its footprint polygon (x0 … z1 hold the bounding box)
        vol.Optional("points", default=None): vol.Any(None, vol.All([_POINT], vol.Length(min=3, max=MAX_POINTS))),
        # a dormer on the slope of another section
        vol.Optional("dormer", default=False): bool,
        vol.Optional("locked", default=False): bool,
        # a canopy (terrace roof, carport): posts instead of walls, a see-through roof
        vol.Optional("open", default=False): bool,
        # gable, hip and half-hip: how the ridge ends at either end (None = as the shape, #466)
        vol.Optional("end_u0", default=None): vol.Any(None, vol.In(["gable", "hip", "halfhip"])),
        vol.Optional("end_u1", default=None): vol.Any(None, vol.In(["gable", "hip", "halfhip"])),
        # turned (degrees, clockwise in the plan) about a pivot point: a wing at an angle (#634, #724)
        vol.Optional("rotation", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=-360, max=360))),
        vol.Optional("pivot", default=None): vol.Any(None, _POINT),
    },
    extra=vol.ALLOW_EXTRA,
)

# a field of solar modules on a roof face: rows x columns from its lower left corner on the face
SOLAR_FIELD_SCHEMA = vol.Schema(
    {
        vol.Required("id"): _ID,
        vol.Required("face"): vol.All(str, vol.Length(max=80)),
        vol.Required("u"): vol.All(vol.Coerce(float), vol.Range(min=-50, max=200)),
        vol.Required("v"): vol.All(vol.Coerce(float), vol.Range(min=-50, max=200)),
        vol.Required("rows"): vol.All(int, vol.Range(min=1, max=40)),
        vol.Required("cols"): vol.All(int, vol.Range(min=1, max=60)),
        vol.Optional("portrait", default=True): bool,
        # frames on flat ground (up to 45 degrees), away from a wall (up to 90: a canopy)
        vol.Optional("tilt", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=90))),
        vol.Optional("flip", default=False): bool,
        vol.Optional("entity", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        vol.Optional("name", default=None): vol.Any(None, vol.All(str, vol.Length(max=80))),
        # modules per row when the rows differ, how shorter rows sit, modules left out ("row:column")
        vol.Optional("layout", default=None): vol.Any(
            None, vol.All([vol.All(int, vol.Range(min=0, max=60))], vol.Length(max=40))
        ),
        vol.Optional("align", default=None): vol.Any(None, vol.In(["left", "center", "right"])),
        vol.Optional("skip", default=None): vol.Any(
            None, vol.All([vol.All(str, vol.Length(max=12))], vol.Length(max=2400))
        ),
        vol.Optional("look", default=None): vol.Any(None, vol.In(["black", "blue"])),
        # module size in portrait (None = 1.13 x 1.72 m) and the string the field belongs to
        vol.Optional("module_w", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0.3, max=3))),
        vol.Optional("module_h", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0.3, max=3))),
        # peak power of one module in Wp (None = 400)
        vol.Optional("wp", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=50, max=1500))),
        vol.Optional("string", default=None): vol.Any(None, _ID),
        # garden fields (face "ground"): rotation of the rows in the plan
        vol.Optional("rotation", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=-360, max=360))),
        # free-standing fields: height of the surface they stand on (a garage roof); None = the ground
        vol.Optional("base", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=60))),
        vol.Optional("locked", default=False): bool,
    },
    extra=vol.ALLOW_EXTRA,
)

# a string of solar modules: fields wired together to one inverter
SOLAR_STRING_SCHEMA = vol.Schema(
    {
        vol.Required("id"): _ID,
        vol.Required("name"): vol.All(str, vol.Length(max=80)),
        vol.Optional("entity", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        vol.Optional("inverter", default=None): vol.Any(None, _ID),
    },
    extra=vol.ALLOW_EXTRA,
)

# a roof window on a roof face, with an optional blind (cover) and contacts
ROOF_WINDOW_SCHEMA = vol.Schema(
    {
        vol.Required("id"): _ID,
        vol.Required("face"): vol.All(str, vol.Length(max=80)),
        vol.Required("u"): vol.All(vol.Coerce(float), vol.Range(min=-50, max=200)),
        vol.Required("v"): vol.All(vol.Coerce(float), vol.Range(min=-50, max=200)),
        vol.Optional("w", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0.3, max=4))),
        vol.Optional("h", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0.3, max=4))),
        vol.Optional("cover", default=None): _ENTITY_REF,
        vol.Optional("contact", default=None): _ENTITY_REF,
        vol.Optional("tilt", default=None): _ENTITY_REF,
        # a window motor: a cover whose position opens the sash that far
        vol.Optional("window", default=None): _ENTITY_REF,
        vol.Optional("name", default=None): vol.Any(None, vol.All(str, vol.Length(max=64))),
        vol.Optional("locked", default=False): bool,
        # stays over its room when the roof fades out (off: shown in the roof only)
        vol.Optional("float", default=False): bool,
    },
    extra=vol.ALLOW_EXTRA,
)

# Energie Pro: a cable laid by hand: its way in the plan at a height above its floor
CABLE_SCHEMA = vol.Schema(
    {
        vol.Required("id"): vol.All(str, vol.Length(max=80)),
        vol.Required("floor_id"): _ID,
        vol.Required("points"): vol.All([_POINT], vol.Length(min=1, max=60)),
        vol.Optional("height", default=0.03): vol.All(vol.Coerce(float), vol.Range(min=0, max=30)),
        vol.Optional("locked", default=False): bool,
    },
    extra=vol.ALLOW_EXTRA,
)

# Energie Pro: the hologram hangs on a solar field, moved along it and scaled
HOLOGRAM_SCHEMA = vol.Schema(
    {
        vol.Optional("place", default="field"): vol.In(["field", "free"]),
        vol.Optional("field", default=None): vol.Any(None, _ID),
        vol.Optional("x", default=0.0): vol.All(vol.Coerce(float), vol.Range(min=-500, max=500)),
        vol.Optional("z", default=0.0): vol.All(vol.Coerce(float), vol.Range(min=-500, max=500)),
        vol.Optional("height", default=3.0): vol.All(vol.Coerce(float), vol.Range(min=0, max=60)),
        vol.Optional("size", default=1.0): vol.All(vol.Coerce(float), vol.Range(min=0.3, max=3)),
        vol.Optional("right", default=0.0): vol.All(vol.Coerce(float), vol.Range(min=-30, max=30)),
        vol.Optional("up", default=0.0): vol.All(vol.Coerce(float), vol.Range(min=-30, max=30)),
        # seen from behind the field the card shows its back, mirrored like glass (off: always readable)
        vol.Optional("mirror", default=True): bool,
        # device cards hide while their device draws less than this (W; 0 = always shown)
        vol.Optional("device_house", default=True): bool,
        vol.Optional("device_room", default=False): bool,
        # the house balance and the plant cards also in a floor view
        vol.Optional("plant_floor", default=False): bool,
        vol.Optional("device_min_w", default=0): vol.All(vol.Coerce(float), vol.Range(min=0, max=100000)),
    },
    extra=vol.ALLOW_EXTRA,
)

ROOF_SCHEMA = vol.Schema(
    {
        vol.Optional("type", default="none"): vol.In(["none", "flat", "gable", "custom"]),
        # roof sections of a "custom" roof
        vol.Optional("sections", default=list): vol.All([ROOF_SECTION_SCHEMA], vol.Length(max=64)),
        # solar fields on the roof faces
        vol.Optional("solar", default=list): vol.All([SOLAR_FIELD_SCHEMA], vol.Length(max=32)),
        vol.Optional("strings", default=list): vol.All([SOLAR_STRING_SCHEMA], vol.Length(max=16)),
        vol.Optional("windows", default=list): vol.All([ROOF_WINDOW_SCHEMA], vol.Length(max=32)),
        vol.Optional("hologram", default=None): vol.Any(None, HOLOGRAM_SCHEMA),
        vol.Optional("cables", default=list): vol.All([CABLE_SCHEMA], vol.Length(max=64)),
        vol.Optional("pitch", default=35): vol.All(vol.Coerce(float), vol.Range(min=5, max=60)),
        vol.Optional("overhang", default=0.4): vol.All(vol.Coerce(float), vol.Range(min=0, max=2)),
        # gable roof: ridge along the long side (None) or along the short side (terraced houses)
        vol.Optional("ridge", default=None): vol.Any(None, vol.In(["long", "short"])),
    },
    extra=vol.ALLOW_EXTRA,
)

FREE_WALL_SCHEMA = vol.Schema(
    {
        vol.Required("id"): _ID,
        vol.Required("a"): _POINT,
        vol.Required("b"): _POINT,
        vol.Optional("thickness", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0.02, max=1))),
        vol.Optional("height", default=None): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0.05, max=20))),
        # a sloping top (#834): the height at end a and at end b (None = the plain height)
        vol.Optional("slope"): vol.Any(
            None,
            vol.All([vol.All(vol.Coerce(float), vol.Range(min=0.05, max=20))], vol.Length(min=2, max=2)),
        ),
        # colour of both sides (#1101, homely styles; None = the room's wall or the facade)
        vol.Optional("color"): vol.Any(None, vol.All(str, vol.Length(max=16))),
    },
    extra=vol.ALLOW_EXTRA,
)

FLOOR_SCHEMA = vol.Schema(
    {
        vol.Required("id"): _ID,
        vol.Required("name"): _NAME,
        vol.Required("elevation"): vol.All(vol.Coerce(float), vol.Range(min=-100, max=500)),
        vol.Required("height"): vol.All(vol.Coerce(float), vol.Range(min=1, max=20)),
        vol.Required("cut_height"): vol.All(vol.Coerce(float), vol.Range(min=0.2, max=20)),
        vol.Required("rooms"): vol.All([ROOM_SCHEMA], vol.Length(max=MAX_ROOMS)),
        vol.Required("openings"): vol.All([OPENING_SCHEMA], vol.Length(max=MAX_ITEMS)),
        vol.Required("furniture"): vol.All([FURNITURE_SCHEMA], vol.Length(max=MAX_ITEMS)),
        vol.Required("placements"): vol.All([PLACEMENT_SCHEMA], vol.Length(max=MAX_ITEMS)),
        vol.Required("background"): vol.Any(None, BACKGROUND_SCHEMA),
        vol.Optional("outdoor", default=list): vol.All([OUTDOOR_SCHEMA], vol.Length(max=MAX_ITEMS)),
        # free-standing walls (partitions); room walls come from the room edges
        vol.Optional("walls", default=list): vol.All([FREE_WALL_SCHEMA], vol.Length(max=MAX_ITEMS)),
        # floor of Home Assistant's floor registry this floor stands for
        vol.Optional("ha_floor", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # the camera this floor opens with (None = the house view's side)
        vol.Optional("start_view", default=None): vol.Any(None, START_VIEW_SCHEMA),
    },
    extra=vol.ALLOW_EXTRA,
)


# the styles' text settings: the house's plan for day, evening and night, a helper entity, the facade colour
_STYLE_TEXTS: dict[Any, Any] = {
    vol.Optional(key): vol.Any(None, vol.All(str, vol.Length(max=64)))
    for key in (
        "style_day",
        "style_evening",
        "style_night",
        "style_morning_at",
        "style_evening_at",
        "style_night_at",
        "style_entity",
        "facade_color",
    )
}


# the neighbourhood from OpenStreetMap (surroundings.ts): map metres around the home, fetched once in the browser
_SURROUND_POLY = vol.All([_POINT], vol.Length(min=2, max=MAX_POINTS))
SURROUNDINGS_SCHEMA = vol.Schema(
    {
        vol.Required("on"): bool,
        vol.Required("lat"): vol.All(vol.Coerce(float), vol.Range(min=-90, max=90)),
        vol.Required("lon"): vol.All(vol.Coerce(float), vol.Range(min=-180, max=180)),
        vol.Required("at"): vol.All(vol.Coerce(float), vol.Range(min=0)),
        vol.Required("radius"): vol.All(vol.Coerce(float), vol.Range(min=20, max=600)),
        vol.Required("x"): _COORD,
        vol.Required("z"): _COORD,
        vol.Optional("own"): vol.Any(None, vol.All(int, vol.Range(min=0))),
        vol.Optional("hide"): vol.All([vol.All(int, vol.Range(min=0))], vol.Length(max=3000)),
        vol.Optional("show"): vol.All([vol.All(int, vol.Range(min=0))], vol.Length(max=3000)),
        vol.Optional("flat"): bool,
        vol.Optional("roofs"): bool,
        vol.Optional("y"): vol.All(vol.Coerce(float), vol.Range(min=-30, max=30)),
        vol.Required("buildings"): vol.All(
            [
                vol.Schema(
                    {
                        vol.Required("p"): _SURROUND_POLY,
                        vol.Required("h"): vol.All(vol.Coerce(float), vol.Range(min=0, max=400)),
                    }
                )
            ],
            vol.Length(max=3000),
        ),
        vol.Required("ways"): vol.All(
            [
                vol.Schema(
                    {
                        vol.Required("p"): _SURROUND_POLY,
                        vol.Required("w"): vol.All(vol.Coerce(float), vol.Range(min=0, max=60)),
                        vol.Required("k"): vol.In(["road", "path", "rail", "water"]),
                    }
                )
            ],
            vol.Length(max=3000),
        ),
        vol.Required("areas"): vol.All(
            [vol.Schema({vol.Required("p"): _SURROUND_POLY, vol.Required("k"): vol.In(["water", "green", "wood"])})],
            vol.Length(max=500),
        ),
        vol.Required("trees"): vol.All([_POINT], vol.Length(max=3000)),
    }
)

SETTINGS_SCHEMA = vol.Schema(
    {
        vol.Required("wall_exterior"): vol.All(vol.Coerce(float), vol.Range(min=0.02, max=1)),
        vol.Required("wall_interior"): vol.All(vol.Coerce(float), vol.Range(min=0.02, max=1)),
        vol.Required("grid"): vol.All(vol.Coerce(float), vol.Range(min=0.01, max=1)),
        # direction of north in the plan, degrees clockwise from "up"
        vol.Optional("north", default=0): vol.All(vol.Coerce(float), vol.Range(min=-360, max=360)),
        # lengths in the editor: metric or imperial (None = Home Assistant's unit system); storage stays metric
        vol.Optional("units", default=None): vol.Any(None, vol.In(["metric", "imperial"])),
        # located people in 3D: a neon figure (None = default), a pin, or not at all
        vol.Optional("person_look", default=None): vol.Any(None, vol.In(["figure", "pin", "off"])),
        # plan lock: rooms, walls, doors, windows and outdoor areas cannot be moved by accident
        vol.Optional("lock_plan", default=False): bool,
        # size of the room names in 3D (1 = as before)
        vol.Optional("label_scale"): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0.5, max=2))),
        vol.Optional("surroundings"): vol.Any(None, SURROUNDINGS_SCHEMA),
        # stations and playlists for the speakers' quick menu (media_player.play_media type + content id)
        vol.Optional("media_presets", default=list): vol.All(
            [
                vol.Schema(
                    {
                        vol.Required("id"): vol.All(str, vol.Length(min=1, max=64)),
                        vol.Required("label"): vol.All(str, vol.Length(max=60)),
                        vol.Required("type"): vol.All(str, vol.Length(max=40)),
                        vol.Required("content"): vol.All(str, vol.Length(max=500)),
                    },
                    extra=vol.ALLOW_EXTRA,
                )
            ],
            vol.Length(max=30),
        ),
        # own buttons in the central menu: navigate, more-info, a service or a DOM event (browser_mod popup)
        vol.Optional("buttons", default=list): vol.All(
            [
                vol.Schema(
                    {
                        vol.Required("id"): vol.All(str, vol.Length(min=1, max=64)),
                        vol.Required("label"): vol.All(str, vol.Length(max=60)),
                        vol.Optional("icon", default=None): vol.Any(None, vol.All(str, vol.Length(max=64))),
                        vol.Required("action"): vol.In(["navigate", "more_info", "service", "fire_dom_event"]),
                        vol.Optional("target", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
                        vol.Optional("data", default=None): vol.Any(None, dict),
                    },
                    extra=vol.ALLOW_EXTRA,
                )
            ],
            vol.Length(max=20),
        ),
        # favourites of the house in the central menu of the 3D view (scenes, scripts, switches …)
        vol.Optional("favorites", default=list): vol.All([vol.All(str, vol.Length(max=255))], vol.Length(max=40)),
        # the camera the house view opens with (None = fitted from the front left)
        vol.Optional("start_view", default=None): vol.Any(None, START_VIEW_SCHEMA),
        vol.Optional("roof", default=lambda: {"type": "none", "pitch": 35, "overhang": 0.4}): ROOF_SCHEMA,
        # the weather entity for the weather outside (None = the first one)
        vol.Optional("weather_entity", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # which weather effects the 3D view shows (None = all but fog)
        # warning for a window open while it rains
        vol.Optional("rain_warning", default=True): bool,
        # rain from an own weather station (a rain sensor or rain rate) instead of the weather entity
        vol.Optional("rain_entity", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # warnings name the device after the room
        vol.Optional("alert_names", default=True): bool,
        vol.Optional("alert_unavailable", default=False): bool,
        # an entity that reports a power outage (None = no outage warning)
        vol.Optional("outage_entity", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
        # sunlight through the windows as patches on the floor
        vol.Optional("sun_patches", default=True): bool,
        vol.Optional("sun_shadow", default=True): bool,
        vol.Optional("sky"): bool,
        vol.Optional("flyin"): bool,
        # what the sun's arc and compass ring stand around: the house (None, default) or the whole plot (#833)
        vol.Optional("sun_arc"): vol.Any(None, vol.In(["house", "plot"])),
        vol.Optional("window_glow", default=True): bool,
        # devices switch only in an opened room; elsewhere a tap opens the room
        vol.Optional("tap_in_room", default=False): bool,
        # a short right click in 3D goes one step back
        vol.Optional("right_click_back", default=False): bool,
        # fun pack "Halloween": the ghost floating through the house (on unless switched off)
        # Haushalt Pro: the hours a waste bin glows (from the day before, until on the day)
        vol.Optional("household"): vol.Any(
            None,
            vol.Schema(
                {
                    vol.Optional("bin_from"): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=24))),
                    vol.Optional("bin_until"): vol.Any(None, vol.All(vol.Coerce(float), vol.Range(min=0, max=24))),
                    # only the bins of the next pickup wear a tag; tags only from some days before (None = always)
                    vol.Optional("bin_next_only"): vol.Any(None, bool),
                    vol.Optional("bin_days"): vol.Any(None, vol.All(vol.Coerce(int), vol.Range(min=0, max=60))),
                    # calendars whose entries of today stand in the glass card "Today in the household"
                    vol.Optional("calendars"): vol.Any(
                        None, vol.All([vol.All(str, vol.Length(max=255))], vol.Length(max=10))
                    ),
                },
                extra=vol.ALLOW_EXTRA,
            ),
        ),
        # the styles: the house's plan for day, evening and night, how it switches, a helper entity naming the style,
        # and the facade colour of the homely styles
        **_STYLE_TEXTS,
        vol.Optional("style_switch"): vol.Any(None, vol.In(["sun", "time"])),
        # own styles: built-in ones adjusted and named (their settings are checked by the frontend)
        vol.Optional("styles_custom"): vol.Any(None, vol.All([dict], vol.Length(max=40))),
        # the background behind the 3D house (None = the look's own sky): a colour, a gradient or a picture
        vol.Optional("backdrop", default=None): vol.Any(
            None,
            vol.Schema(
                {
                    vol.Optional("kind", default=None): vol.Any(None, vol.In(["color", "gradient", "image"])),
                    vol.Optional("color", default=None): vol.Any(None, vol.All(str, vol.Length(max=16))),
                    vol.Optional("color2", default=None): vol.Any(None, vol.All(str, vol.Length(max=16))),
                    vol.Optional("image", default=None): vol.Any(None, vol.All(str, vol.Length(max=2048))),
                    vol.Optional("dim", default=None): vol.Any(
                        None, vol.All(vol.Coerce(float), vol.Range(min=0, max=0.9))
                    ),
                },
                extra=vol.ALLOW_EXTRA,
            ),
        ),
        # Kamera-Cockpit: the live director - events a wall screen shows by itself (all off unless switched on)
        vol.Optional("director", default=None): vol.Any(
            None,
            vol.Schema(
                {
                    vol.Optional("doorbell", default=False): bool,
                    vol.Optional("doorbell_entity", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
                    vol.Optional("doorbell_camera", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
                    vol.Optional("motion", default="off"): vol.In(["off", "person", "all"]),
                    vol.Optional("appliances", default=False): bool,
                    vol.Optional("alerts", default=False): bool,
                    vol.Optional("live", default=False): bool,
                    vol.Optional("triggers", default=None): vol.Any(
                        None,
                        vol.All(
                            [
                                vol.Schema(
                                    {
                                        vol.Required("entity"): vol.All(str, vol.Length(max=255)),
                                        vol.Optional("camera", default=None): _ENTITY_REF,
                                    }
                                )
                            ],
                            vol.Length(max=20),
                        ),
                    ),
                    vol.Optional("hold", default=None): vol.Any(
                        None, vol.All(vol.Coerce(float), vol.Range(min=10, max=600))
                    ),
                },
                extra=vol.ALLOW_EXTRA,
            ),
        ),
        vol.Optional("halloween", default=None): vol.Any(
            None, vol.Schema({vol.Optional("ghost", default=True): bool}, extra=vol.ALLOW_EXTRA)
        ),
        # fun pack "Winter & Christmas": fairy lights along the eaves, snow, the New Year's firework
        vol.Optional("winter", default=None): vol.Any(
            None,
            vol.Schema(
                {
                    vol.Optional("roof_lights", default=True): bool,
                    vol.Optional("roof_entity", default=None): vol.Any(None, vol.All(str, vol.Length(max=255))),
                    vol.Optional("roof_color", default=False): bool,
                    vol.Optional("snow", default=True): bool,
                    vol.Optional("firework", default=True): bool,
                },
                extra=vol.ALLOW_EXTRA,
            ),
        ),
        # the ground around the house: its height and the earth around cellars
        vol.Optional("terrain", default=None): vol.Any(
            None,
            vol.Schema(
                {
                    vol.Optional("level", default=None): vol.Any(
                        None, vol.All(vol.Coerce(float), vol.Range(min=-20, max=20))
                    ),
                    vol.Optional("earth", default=True): bool,
                },
                extra=vol.ALLOW_EXTRA,
            ),
        ),
        vol.Optional("weather_effects", default=None): vol.Any(
            None, [vol.In(["rain", "snow", "fog", "clouds", "lightning", "sky"])]
        ),
        # fun pack "pets": animals that live in the 3D house (switched on and off)
        vol.Optional("pets", default=None): vol.Any(
            None,
            vol.Schema(
                {
                    vol.Optional("on", default=True): bool,
                    vol.Optional("list", default=list): vol.All(
                        [
                            vol.Schema(
                                {
                                    vol.Required("id"): vol.All(str, vol.Length(min=1, max=64)),
                                    vol.Required("kind"): vol.In(["cat", "dog", "rabbit"]),
                                    vol.Optional("name", default=""): vol.All(str, vol.Length(max=30)),
                                    vol.Optional("fur", default="orange"): vol.All(str, vol.Length(max=20)),
                                    vol.Optional("breed", default=None): vol.Any(
                                        None, vol.All(str, vol.Length(max=20))
                                    ),
                                    vol.Optional("floor_id", default=None): vol.Any(
                                        None, vol.All(str, vol.Length(max=64))
                                    ),
                                },
                                extra=vol.ALLOW_EXTRA,
                            )
                        ],
                        vol.Length(max=8),
                    ),
                },
                extra=vol.ALLOW_EXTRA,
            ),
        ),
        # what a module keeps for this room or the whole house (its settings), by the module's id
        vol.Optional("mods"): _MODULE_DATA,
    },
    extra=vol.ALLOW_EXTRA,
)

_ENTITY = vol.Any(None, vol.All(str, vol.Length(max=255)))

METER_SCHEMA = vol.Schema(
    {vol.Required("floor_id"): _ID, vol.Required("x"): _COORD, vol.Required("z"): _COORD}, extra=vol.ALLOW_EXTRA
)

ENERGY_DEFAULTS = {
    "meter": None,
    "grid": None,
    "grid_invert": False,
    "solar": None,
    "battery": None,
    "battery_invert": False,
    "battery_soc": None,
    "consumption": None,
    "tariff": None,
    "gas": None,
    "water": None,
}

# Power sensors in watts: grid positive = import, battery positive = discharging (both can be inverted)
ENERGY_SCHEMA = vol.Schema(
    {
        vol.Optional("meter", default=None): vol.Any(None, METER_SCHEMA),
        # the cables meet at the point `meter` (e.g. the house board) instead of the meter cabinet (#841)
        vol.Optional("hub_point"): bool,
        vol.Optional("grid", default=None): _ENTITY,
        vol.Optional("grid_invert", default=False): bool,
        vol.Optional("solar", default=None): _ENTITY,
        vol.Optional("battery", default=None): _ENTITY,
        vol.Optional("battery_invert", default=False): bool,
        vol.Optional("battery_soc", default=None): _ENTITY,
        vol.Optional("consumption", default=None): _ENTITY,
        vol.Optional("tariff", default=None): _ENTITY,
        # Energie Pro: gas and water meters (counters, e.g. m³); the house card shows today's use
        vol.Optional("gas", default=None): _ENTITY,
        vol.Optional("water", default=None): _ENTITY,
    },
    extra=vol.ALLOW_EXTRA,
)

# Which sensor tells the room of a person (ESPresense, Bermuda: the state is a room or area name)
PRESENCE_SCHEMA = vol.Schema(
    {vol.Required("person"): vol.All(str, vol.Length(max=255)), vol.Required("sensor"): _ENTITY},
    extra=vol.ALLOW_EXTRA,
)

# A card template (see the editor's settings "Card templates"): a dashboard card on a wall tablet names it and takes
# its options from here, so a change in the editor reaches every tablet. The options are the card's (checked there).
CARD_TEMPLATE_SCHEMA = vol.Schema(
    {
        vol.Required("id"): vol.All(str, vol.Length(min=1, max=60)),
        vol.Required("name"): vol.All(str, vol.Length(max=80)),
        vol.Optional("config", default=dict): vol.Schema({}, extra=vol.ALLOW_EXTRA),
    },
    extra=vol.ALLOW_EXTRA,
)

BUILDING_SCHEMA = vol.Schema(
    {
        vol.Required("version"): 1,
        vol.Required("floors"): vol.All([FLOOR_SCHEMA], vol.Length(max=MAX_FLOORS)),
        vol.Required("settings"): SETTINGS_SCHEMA,
        vol.Optional("energy", default=lambda: dict(ENERGY_DEFAULTS)): ENERGY_SCHEMA,
        vol.Optional("presence", default=list): vol.All([PRESENCE_SCHEMA], vol.Length(max=50)),
        vol.Optional("card_templates"): vol.All([CARD_TEMPLATE_SCHEMA], vol.Length(max=30)),
    },
    extra=vol.ALLOW_EXTRA,
)

IMAGE_DATA = vol.All(
    str,
    vol.Length(max=MAX_IMAGE_CHARS),
    vol.Match(r"^data:image/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$"),
)


def empty_building() -> dict:
    """Return a building without floors."""
    return {
        "version": 1,
        "floors": [],
        "settings": {"wall_exterior": 0.24, "wall_interior": 0.12, "grid": 0.05},
        "energy": dict(ENERGY_DEFAULTS),
        "presence": [],
    }


def image_ids(building: dict) -> set[str]:
    """Return the ids of all images a building refers to: floor backgrounds and screen pictures."""
    ids = {floor["background"]["image_id"] for floor in building.get("floors", []) if floor.get("background")}
    for floor in building.get("floors", []):
        for item in floor.get("furniture", []):
            for rule in item.get("pictures") or []:
                # a URL or a camera ("camera:<entity>") is no stored image
                if not rule["image"].startswith(("http://", "https://", "camera:")):
                    ids.add(rule["image"])
    return ids
